# [1.11.0](https://github.com/slow/nitro-sniper/compare/v1.10.4...v1.11.0) (2021-06-12)


### Features

* message link in embed title ([8153717](https://github.com/slow/nitro-sniper/commit/8153717b438b4dc1645e2b35e9146cb1c00eaba6))

## [1.10.4](https://github.com/slow/nitro-sniper/compare/v1.10.3...v1.10.4) (2021-06-11)


### Bug Fixes

* grab default payment method instead ([56cf452](https://github.com/slow/nitro-sniper/commit/56cf4529eb221027317d1ae56b961c0a3782a501))

## [1.10.3](https://github.com/slow/nitro-sniper/compare/v1.10.2...v1.10.3) (2021-06-11)


### Bug Fixes

* everything cause im dumb ([76e6c09](https://github.com/slow/nitro-sniper/commit/76e6c091847c53bf705516ad4483ad40e6cd1722))

## [1.10.2](https://github.com/slow/nitro-sniper/compare/v1.10.1...v1.10.2) (2021-06-11)


### Bug Fixes

* locked versions ([586eb10](https://github.com/slow/nitro-sniper/commit/586eb10522c8ad90749ba513d8173778373eb065))

## [1.10.1](https://github.com/slow/nitro-sniper/compare/v1.10.0...v1.10.1) (2021-06-11)


### Bug Fixes

* missed a place where null propagation can be used ([2396d7b](https://github.com/slow/nitro-sniper/commit/2396d7b3afb548236fb5821dc205434e6a53ee59))

# [1.10.0](https://github.com/slow/nitro-sniper/compare/v1.9.0...v1.10.0) (2021-06-11)


### Features

* status changer | closes [#130](https://github.com/slow/nitro-sniper/issues/130) ([37295c1](https://github.com/slow/nitro-sniper/commit/37295c1bfbd8131cacb7ee1b4b001976c347b563))

# [1.9.0](https://github.com/slow/nitro-sniper/compare/v1.8.2...v1.9.0) (2021-06-08)


### Features

* new parsing system to make it easier ([a68ca0f](https://github.com/slow/nitro-sniper/commit/a68ca0f7b1ca093e5edabfb405e51ea810f9dc7c))

## [1.8.2](https://github.com/slow/nitro-sniper/compare/v1.8.1...v1.8.2) (2021-06-07)


### Bug Fixes

* force release ([13217c6](https://github.com/slow/nitro-sniper/commit/13217c6e44f4134f43327a6c16359bedfcff7b4f))

## [1.8.1](https://github.com/slow/nitro-sniper/compare/v1.8.0...v1.8.1) (2021-04-24)
 

### Bug Fixes

* npm semver ([9fb7e78](https://github.com/slow/nitro-sniper/commit/9fb7e7865cd1f8be0ff8275f527e3b1d815e2c8e))

# [1.8.0](https://github.com/slow/nitro-sniper/compare/v1.7.2...v1.8.0) (2021-02-20)


### Features

* fix the fucking heroku issue once and for all ([87ce783](https://github.com/slow/nitro-sniper/commit/87ce783901d72ff5566ef901ecc0d8fcd0f2f333))

## [1.7.2](https://github.com/slow/nitro-sniper/compare/v1.7.1...v1.7.2) (2021-02-20)


### Bug Fixes

* heroku suspension | closes [#29](https://github.com/slow/nitro-sniper/issues/29) ([cd5431f](https://github.com/slow/nitro-sniper/commit/cd5431f7001aa015b1c1121b6377d7daafe09eb4))

## [1.7.1](https://github.com/slow/nitro-sniper/compare/v1.7.0...v1.7.1) (2021-02-20)


### Bug Fixes

* dumb fuck ([6c01c14](https://github.com/slow/nitro-sniper/commit/6c01c146a6a07d94c96f6b69b9dd989796ada15e))

# [1.7.0](https://github.com/slow/nitro-sniper/compare/v1.6.6...v1.7.0) (2021-02-15)


### Features

* revert changes ([3735db2](https://github.com/slow/nitro-sniper/commit/3735db2d03ec20eef7e37c6b8bb323b4bd9c9d49))

## [1.6.2](https://github.com/slow/nitro-sniper/compare/v1.6.1...v1.6.2) (2021-02-09)


### Bug Fixes

* closes [#18](https://github.com/slow/nitro-sniper/issues/18) ([a53c6fe](https://github.com/slow/nitro-sniper/commit/a53c6fe8192b8f24be08b5baba344f83736224c3))

## [1.6.1](https://github.com/slow/nitro-sniper/compare/v1.6.0...v1.6.1) (2021-02-07)


### Bug Fixes

* low iq ([d5fb5f5](https://github.com/slow/nitro-sniper/commit/d5fb5f544cb5aea0e8966398b5785f7d618064e6))

# [1.6.0](https://github.com/slow/nitro-sniper/compare/v1.5.3...v1.6.0) (2021-02-07)


### Features

* webhook support for invite join ([bf5b38c](https://github.com/slow/nitro-sniper/commit/bf5b38c04a8bc172e2feb35c9896a57229ed7acc))

## [1.5.3](https://github.com/slow/nitro-sniper/compare/v1.5.2...v1.5.3) (2021-02-07)


### Bug Fixes

* readme type ([d2f6c79](https://github.com/slow/nitro-sniper/commit/d2f6c793b30ce9e9328289d6eedc26bcdedf6c06))

## [1.5.2](https://github.com/slow/nitro-sniper/compare/v1.5.1...v1.5.2) (2021-02-07)


### Bug Fixes

* unverified accs ([2e70cc6](https://github.com/slow/nitro-sniper/commit/2e70cc67552e733220afb854c7ae78ae3c3c16da))

## [1.5.1](https://github.com/slow/nitro-sniper/compare/v1.5.0...v1.5.1) (2021-02-07)


### Bug Fixes

* check for max servers ([0e6c21c](https://github.com/slow/nitro-sniper/commit/0e6c21c73772b9d400ce5786218efc6cdfb85df2))

# [1.5.0](https://github.com/slow/nitro-sniper/compare/v1.4.1...v1.5.0) (2021-02-07)


### Features

* invite sniper ([3955351](https://github.com/slow/nitro-sniper/commit/39553517b51ef9dcba5a6d7c7c7ccfefccd0d14b))

## [1.4.1](https://github.com/slow/nitro-sniper/compare/v1.4.0...v1.4.1) (2021-02-07)


### Bug Fixes

* handle cooldown on messages with multiple codes ([e71b238](https://github.com/slow/nitro-sniper/commit/e71b23886c005590bae8fa6051ea36b2d92b8aa2))

# [1.4.0](https://github.com/slow/nitro-sniper/compare/v1.3.1...v1.4.0) (2021-02-07)


### Features

* cacheless discord v12 upgrade ([09b283a](https://github.com/slow/nitro-sniper/commit/09b283afd12b8a5610fc67da8425678198068090))

## [1.3.1](https://github.com/slow/nitro-sniper/compare/v1.3.0...v1.3.1) (2021-02-06)


### Bug Fixes

* settings is always defined ([55795ec](https://github.com/slow/nitro-sniper/commit/55795eca862bacad866e82fd7fcb1d8107f63764))

# [1.3.0](https://github.com/slow/nitro-sniper/compare/v1.2.3...v1.3.0) (2021-02-05)


### Features

* handler for unknown responses ([c7dbe0b](https://github.com/slow/nitro-sniper/commit/c7dbe0b4154bb2d5e5c7994372963a05553db94f))

## [1.2.3](https://github.com/slow/nitro-sniper/compare/v1.2.2...v1.2.3) (2021-02-05)


### Bug Fixes

* stupid mistake, sniper will be same as before now. ([74ef3d6](https://github.com/slow/nitro-sniper/commit/74ef3d6d277660e39639ad05f48f94123220e551))

## [1.2.2](https://github.com/slow/nitro-sniper/compare/v1.2.1...v1.2.2) (2021-01-31)


### Bug Fixes

* fire webhook by default when giveaway entered ([a1a35da](https://github.com/slow/nitro-sniper/commit/a1a35da38e18d9ebfbca7b728a77c563bc68e4e1))

## [1.2.1](https://github.com/slow/nitro-sniper/compare/v1.2.0...v1.2.1) (2021-01-31)


### Bug Fixes

* update outdated giveaway react delay ([8c4892b](https://github.com/slow/nitro-sniper/commit/8c4892b393b85b6cb69eb968359902bd27537959))

# [1.2.0](https://github.com/slow/nitro-sniper/compare/v1.1.1...v1.2.0) (2021-01-31)


### Features

* customizable webhook events ([3f99823](https://github.com/slow/nitro-sniper/commit/3f99823a2fad2bb2680d448e9d30e500c2168feb))

## [1.1.1](https://github.com/slow/nitro-sniper/compare/v1.1.0...v1.1.1) (2021-01-31)


### Bug Fixes

* toLowerCase of undefined ([5ce052c](https://github.com/slow/nitro-sniper/commit/5ce052cf996a728f71bce7ce5a159f3512a596ff))

# [1.1.0](https://github.com/slow/nitro-sniper/compare/v1.0.1...v1.1.0) (2021-01-31)


### Features

* per-type customizable pings ([f09793b](https://github.com/slow/nitro-sniper/commit/f09793bdd64403dc3130d108b004ab070993c0dd))

## [1.0.1](https://github.com/slow/nitro-sniper/compare/v1.0.0...v1.0.1) (2021-01-31)


### Bug Fixes

* promise rejection errors ([3f781a5](https://github.com/slow/nitro-sniper/commit/3f781a545ac6279109a99400746dc43a928c6414))

# 1.0.0 (2021-01-31)


### Bug Fixes

* version ([3c49381](https://github.com/slow/nitro-sniper/commit/3c493816dc66bbd77e05499e1eec07df17e63a4a))

## [1.1.11](https://github.com/slow/nitro-sniper/compare/v1.1.10...v1.1.11) (2021-01-31)


### Bug Fixes

* low iq ([1dfa9f8](https://github.com/slow/nitro-sniper/commit/1dfa9f8d00317b635a1ea8e319ed7fab4fdd7f26))

## [1.1.10](https://github.com/slow/nitro-sniper/compare/v1.1.9...v1.1.10) (2021-01-31)


### Bug Fixes

* false positive - closes [#15](https://github.com/slow/nitro-sniper/issues/15) ([e5eb1c5](https://github.com/slow/nitro-sniper/commit/e5eb1c5571fa2abb73eda644e90f628694968ac7))

## [1.1.9](https://github.com/slow/nitro-sniper/compare/v1.1.8...v1.1.9) (2021-01-30)


### Bug Fixes

* don't log the parse error, we already know what it is ([94d6ef8](https://github.com/slow/nitro-sniper/commit/94d6ef8230d5c32682b21473cf7ac995289e6e66))

## [1.1.8](https://github.com/slow/nitro-sniper/compare/v1.1.7...v1.1.8) (2021-01-30)


### Bug Fixes

* handle phone locked accounts & add another fake check ([45055b6](https://github.com/slow/nitro-sniper/commit/45055b62f327d7fd12d0d5e85b99a79f6ef79af8))

## [1.1.7](https://github.com/slow/nitro-sniper/compare/v1.1.6...v1.1.7) (2021-01-30)


### Bug Fixes

* WTF ARE YOU DOING BRAIN ([18fd55f](https://github.com/slow/nitro-sniper/commit/18fd55fdbce974a510600441a39d03cc0d4d8ebf))

## [1.1.6](https://github.com/slow/nitro-sniper/compare/v1.1.5...v1.1.6) (2021-01-30)


### Bug Fixes

* make dm delay dynamic to avoid suspicion ([0b715cc](https://github.com/slow/nitro-sniper/commit/0b715cc04ca82547f13612d0e9f78d4c5569d718))

## [1.1.5](https://github.com/slow/nitro-sniper/compare/v1.1.4...v1.1.5) (2021-01-30)


### Bug Fixes

* adjust giveaway delay as its too low ([44194c0](https://github.com/slow/nitro-sniper/commit/44194c0eb5208122fd0a5325205a5d254876986f))

## [1.1.4](https://github.com/slow/nitro-sniper/compare/v1.1.3...v1.1.4) (2021-01-30)


### Bug Fixes

* closes [#11](https://github.com/slow/nitro-sniper/issues/11) ([7d89eeb](https://github.com/slow/nitro-sniper/commit/7d89eeb10502309890f993b48e9f81b0725dce6e))

## [1.1.3](https://github.com/slow/nitro-sniper/compare/v1.1.2...v1.1.3) (2021-01-29)


### Bug Fixes

* honestly idk why tf i did this ([d86bc1b](https://github.com/slow/nitro-sniper/commit/d86bc1b0f4997914e7c37ed4b3ba1e7e11967b94))

## [1.1.2](https://github.com/slow/nitro-sniper/compare/v1.1.1...v1.1.2) (2021-01-29)


### Bug Fixes

* readme description ([b1c9ada](https://github.com/slow/nitro-sniper/commit/b1c9ada2cf1c55dc8fc98f91fa47916ddca5d232))

## [1.1.1](https://github.com/slow/nitro-sniper/compare/v1.1.0...v1.1.1) (2021-01-29)


### Bug Fixes

* heroku-20 is now default & fix env description ([b679b3b](https://github.com/slow/nitro-sniper/commit/b679b3b97fa1c357bce00380a5b27a01b11f837c))
